/**
 * @license Highcharts JS v8.1.0 (2020-05-05)
 * @module highcharts/modules/accessibility
 * @requires highcharts
 *
 * Accessibility module
 *
 * (c) 2010-2019 Highsoft AS
 * Author: Oystein Moseng
 *
 * License: www.highcharts.com/license
 */
'use strict';

import '../../modules/accessibility/accessibility.js';
